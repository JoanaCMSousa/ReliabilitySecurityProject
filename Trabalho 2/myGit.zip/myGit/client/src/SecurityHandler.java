/**Grupo sc005
 * Francisco João Guimarães Coimbra de Almeida Araújo nº45701
 * Joana Correia Magalhães Sousa nº47084
 * João Marques de Barros Mendes Leal nº46394
 */

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import javax.crypto.spec.SecretKeySpec;



public class SecurityHandler {
	
	private byte[] ivBytes = {0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,
			0x19,0x1A,0x1B,0x1C,0x1D,0x1E,0x1F,0x20};
	private IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);
	private PBEParameterSpec spec = new PBEParameterSpec(ivBytes, 20, ivSpec); //esta a dar mal no linux
	private SecretKey key;
	
	private String password;
	
	/**
	 * Construtor de SecurityHandler
	 * @param password - password que o utilizador defuniu ao iniciar o servidor
	 */
	public SecurityHandler(String password) {
		this.password = password;
	}

	/**
	 * Metodo auxiliar para criar um MAC
	 * @param password - password utilizado para criar uma chave
	 * @param rec_file - ficheiro utilizado para criar o MAC
	 * @return um MAC num array de bytes
	 * @throws Exception
	 */
	private byte[] macFunction (String password,File rec_file) throws Exception{
		File file = new File(rec_file.getPath());
		Mac mac = Mac.getInstance("HmacSHA256");
		SecretKey key = new SecretKeySpec(password.getBytes(), "HmacSHA256");
		mac.init(key);
		FileInputStream fis = new FileInputStream(rec_file.getPath());
		byte[] b = new byte[(int) file.length()];  
	    fis.read(b);
	    mac.update(b);
	    fis.close();
		return mac.doFinal();
	}
	
	/**
	 * Cria um MAC a um ficheiro especifico
	 * @param rec_file - ficheiro a ser utlizado para criar o MAC
	 * @throws Exception
	 */
	public void createMAC(File rec_file) throws Exception {
		
		String loc = rec_file.getPath().split("\\.")[0];
		SecretKey key = new SecretKeySpec(password.getBytes(), "HmacSHA256");
		ObjectOutputStream oosk = new ObjectOutputStream(new FileOutputStream(loc + "macKey.key"));
		ObjectOutputStream oos = new ObjectOutputStream( new FileOutputStream(loc + ".mac") );
	    
		oos.write(macFunction(password,rec_file));
		
		byte[] keyEncoded = key.getEncoded();
		
		oosk.write(keyEncoded);
		oosk.flush();
		oos.flush();
		oosk.close();
		oos.close();
		
	}
	
	
	/**
	 * Metodo que verifica se um dado MAC eh valido
	 * @param rec_file - o ficheiro utilizado para comparar o seu MAC 
	 * anteriormente criado
	 * @return 1 se o MAC eh valido; 0 caso contrario
	 * @throws Exception
	 */
	public int checkMAC(File rec_file) 
			throws Exception{
		String name = rec_file.getPath().split("\\.")[0];
		File macToComp = new File(name+ ".mac");
		
		//para obter a chave secreta
		File macKey = new File(name + "macKey.key");
		ObjectInputStream fisMac = new ObjectInputStream(
				new FileInputStream(name + "macKey.key"));
		byte [] keyEncoded = new byte[(int) macKey.length()];
		fisMac.read(keyEncoded);
		
		SecretKeySpec key = new SecretKeySpec(keyEncoded, "HmacSHA256");
		
		//criar um novo mac para comparar com o original
		Mac mac = Mac.getInstance("HmacSHA256");
		mac.init(key);
		FileInputStream fis = new FileInputStream(rec_file.getPath());
		byte[] b = new byte[(int) rec_file.length()];  
	    fis.read(b);
	    mac.update(b);
	    fis.close();
		
		byte[] newMac = macFunction(password,rec_file);  
	  
		fisMac.close();
	    
	    //comparacao dos macs
	    byte[] fileBytes = Files.readAllBytes(macToComp.toPath());
	    byte[] originalMac = Arrays.copyOfRange(fileBytes, 6, fileBytes.length);
	    
	    if(originalMac.length != newMac.length)
	    	return 0;
				
	   if(!Arrays.equals(originalMac,newMac))
		   return 0;

	    
		return 1;
		
	}
	
	/**
	 * Funcao que cria uma chave com o algoritmo PBEWithHmacSHA256AndAES_128
	 * @return uma SecretKey
	 * @throws Exception
	 */
	public SecretKey getRandomSecretKey() throws Exception{
		PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray());
		SecretKeyFactory kf = SecretKeyFactory.getInstance("PBEWithHmacSHA256AndAES_128");
		return kf.generateSecret(keySpec); 
	}
	
	/**
	 * Metodo que obtem uma secretkey a partir de um array de bytes
	 * @param key - um array de bytes por onde vai ser obtido a chave secreta
	 * @return uma secretkey resultante
	 */
	public SecretKey getKeyFromArray(byte[] key){
		return new SecretKeySpec(key,0,key.length,"PBEWithHmacSHA256AndAES_128");
	}
	
	/**
	 * Funcao que envia o ficheiro ecriptado
	 * @param file - ficheiro que vai ser ecriptado e depois enviado
	 * @param key - chave a ser utilizada para ecriptar
	 * @param msg - messager que vai ser utilizado para tratar do envio
	 * @param out - o resultado da ecriptacao
	 */
	public void SendEncryptWithPassword(File file,SecretKey key,Messager msg,ObjectOutputStream out){
		
		Cipher c;
		try {
			c = Cipher.getInstance("PBEWithHmacSHA256AndAES_128");
			c.init(Cipher.ENCRYPT_MODE, key, spec);
			
			FileInputStream fis;
		    FileOutputStream fos;
		    CipherOutputStream cos;
		    
		    fis = new FileInputStream(file);
		   
		    fos = new FileOutputStream(file.getName() + ".cif"); 

		    cos = new CipherOutputStream(fos, c);
		    byte[] b = new byte[1024];  
		    int i = fis.read(b);
		    while (i != -1) {
		        cos.write(b, 0, i);
		        i = fis.read(b);
		    }
		    cos.close();
		    fis.close();
		    File fl = new File(file.getName() + ".cif");
		    msg.sendFile(fl, out);
		    
		    fl.delete();
		    
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Funcao que tratar da decriptacao de um ficheiro usando uma secretkey dada
	 * @param file - ficheiro que vai seu decriptado
	 * @param key - chave a ser utilizada para a decriptacao
	 * @throws Exception
	 */
	public void decryptFile(File file,SecretKey key) throws Exception{
		Cipher c = Cipher.getInstance("PBEWithHmacSHA256AndAES_128");
		c.init(Cipher.DECRYPT_MODE,key,spec);
		String path = file.getPath();
		FileInputStream fis = new FileInputStream(file);
		FileOutputStream fos = new FileOutputStream(path + ".temp");;
		CipherInputStream cis = new CipherInputStream(fis, c);
		File newFile = new File(path + ".temp"); 	
		byte[] b = new byte[16];  
	    int i = cis.read(b);
	    while (i != -1) {
	        fos.write(b, 0, i);
	        i = cis.read(b);
	    }
	    
	    fis.close();
		fos.close();
		cis.close();
		
		if(!file.delete())
			System.out.println("Nao apagou");
		newFile.renameTo(file);
	}
	
	
	/**
	 * Funcao que trata de ecriptacao de um ficheiro
	 * @param file - ficheiro a ser ecriptado
	 * @throws Exception
	 */
	public void encrypthFile(File file) throws Exception{
		PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray());
		SecretKeyFactory kf = SecretKeyFactory.getInstance("PBEWithHmacSHA256AndAES_128");
		key = kf.generateSecret(keySpec); 
		Cipher c = Cipher.getInstance("PBEWithHmacSHA256AndAES_128");
		c.init(Cipher.ENCRYPT_MODE,key,spec);
		String path = file.getPath();
		FileInputStream fis = new FileInputStream(file);
		FileOutputStream fos = new FileOutputStream(path + ".temp");;
		CipherInputStream cis = new CipherInputStream(fis, c);
		File newFile = new File(path + ".temp"); 	
		byte[] b = new byte[16];  
	    int i = cis.read(b);
	    while (i != -1) {
	        fos.write(b, 0, i);
	        i = cis.read(b);
	    }
	    
	    fis.close();
		fos.close();
		cis.close();
		
		if(!file.delete())
			System.out.println("Nao apagou");
		newFile.renameTo(file);
	}
	/**
	 * Funcao que trata da decriptacao de um ficheiro
	 * @param file - ficheiro a ser decriptado
	 * @throws Exception
	 */
	public void decryptFile(File file) throws Exception{
		PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray());
		SecretKeyFactory kf = SecretKeyFactory.getInstance("PBEWithHmacSHA256AndAES_128");
		key = kf.generateSecret(keySpec);
		SecretKeySpec secretSpec = new SecretKeySpec
        		(key.getEncoded(), "PBEWithHmacSHA256AndAES_128");
		Cipher c = Cipher.getInstance("PBEWithHmacSHA256AndAES_128");
		c.init(Cipher.DECRYPT_MODE,secretSpec,spec);
		String path = file.getPath();
		FileInputStream fis = new FileInputStream(file);
		FileOutputStream fos = new FileOutputStream(path + ".temp");;
		CipherInputStream cis = new CipherInputStream(fis, c);
		File newFile = new File(path + ".temp"); 	
		byte[] b = new byte[16];  
	    int i = cis.read(b);
	    while (i != -1) {
	        fos.write(b, 0, i);
	        i = cis.read(b);
	    }
	    
	    fis.close();
		fos.close();
		cis.close();
		
		if(!file.delete())
			System.out.println("Nao apagou");
		newFile.renameTo(file);
	}
	
	
	
	/**
	 * Funcao que gera um nonce aleatoriamente
	 * @return um valor aleatorio
	 */
	public String generateNonce(){
		SecureRandom random = new SecureRandom();
		return new BigInteger(130,random).toString();
	}
	
	
	
	
	/**
	 * Funcao que trata da sintese da mensagem
	 * @param value - mensagem a ser utilizada para tratar da sintese
	 * @return a sinetese da mensagem num array de bytes
	 * @throws NoSuchAlgorithmException
	 */
	public byte[] hash (String value) throws NoSuchAlgorithmException{
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		return md.digest(value.getBytes(StandardCharsets.UTF_8));
	}
	
	
	/**
	 * Funcao que trata da assinatura do ficheiro
	 * @param M - ficheiro pelo qual se vai realizar a assinatura
	 * @param privKey - chave secreta utilizada para fazer a assinatura
	 * @return uma assinatura num array de bytes
	 * @throws Exception
	 */
	public byte[] signature(File M,PrivateKey privKey) throws Exception{
		
		Signature s = Signature.getInstance("SHA256withRSA");
		s.initSign(privKey);
		
		FileInputStream fis = new FileInputStream(M);
		BufferedInputStream bufin = new BufferedInputStream(fis);
		byte[] buffer = new byte[1024];
		int len;
		while ((len = bufin.read(buffer)) >= 0) 
		    s.update(buffer, 0, len);
		
		bufin.close();
		fis.close();
		
		return s.sign();
	}
		
}
